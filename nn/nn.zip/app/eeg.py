# pylint: disable=E1101
# pylint: disable=C0111
import os
import torch
from lib.data import Data
from lib.models import EEG_Net
from lib.metrics import accuracy
from lib.learner import Learner


def eeg(cfg):
    cfg.logger.text('EEG Consciousness Level Classifier')
    if cfg.rm:
        fname = os.path.join(cfg.path, 'models/model_EEG_Net_best.pth.tar')
        if os.path.exists(fname): os.remove(fname)
    data = Data.numpy_from_file(cfg, bs=64)
    #model = EEG_Net(4, 16, [32, 32, 64, 64, 128, 128, 256, 256], data.c, p=0.5)
    model = EEG_Net(4, 16, [32, 32, 32, 32, 32, 32, 32, 32], data.c, p=0.5)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=5e-5)
    crit = torch.nn.NLLLoss()
    learner = Learner(cfg, data, model, opt=opt, crit=crit, metrics=[accuracy])

    if cfg.lr_find:
        cfg.logger.print_lr_find(learner.lr_find())
        exit(0)

    if cfg.predict is not None:
        x = data.pre(cfg.predict)
        y2 = data.pos(learner.predict(x))
        print(f'\nPredict: {cfg.predict} -> {y2}\n')
        exit(0)

    # for b in [1.0, 0.8, 0.6, 0.4, 0.2, 0.0]:
    #    data.ds1.set_balance(b)
    #    learner.fit(1, verbose=False)
    # learner.fit(14)

    #data.ds1.set_balance(1.0)
    learner.fit(cfg.epochs)
    learner.close()
