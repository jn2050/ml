

def gan():
    pass